# PPB-Kalkulator
Tugas PPB setelah UTS - Kalkulator

| Home          | Perhitungan   | Hapus Satu Riwayat |
| ------------- | ------------- | ------------------ |
|![home](https://user-images.githubusercontent.com/96031557/204939180-4e345965-8603-4795-b98a-2bf77be36627.jpg)|![Perhitungan](https://user-images.githubusercontent.com/96031557/204939283-1a7ec0ea-e5b5-4f63-be2c-5aed7d6a3f71.jpg)| ![hapus](https://user-images.githubusercontent.com/96031557/204939761-7ffcc213-3bd8-418f-b737-d26a6eeb9ab7.jpg)

